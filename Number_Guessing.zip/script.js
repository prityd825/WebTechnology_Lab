var C;
C= prompt("Temperature in celcius: ");

var F;
F = 9/5*C+32;
alert("Fahrenheit: "+F);
console.log("Task Complete!");
