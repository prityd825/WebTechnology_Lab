<!DOCTYPE html>
<html>
    <head>
        <title>Mark Sheet</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
       <h1>Mark Sheet</h1>
        <div>
        <?php include "Connection.php"; ?>
        <form action="mark_sheet_task.php" method="post">
            <table align = "center">
                <tr>
                    <td class="student_id"> Student ID </td>
                    <td colspan="36">Marks</td>
                    <td> Total </td>
                </tr>
                <tr>
                    <td rowspan="4"><input type="text" class="small-input" name ="id" required></td>
                    <td colspan="4">Q:1</td>
                    <td colspan="4">Q:2</td>
                    <td colspan="4">Q:3</td>
                    <td colspan="4">Q:4</td>
                    <td colspan="4">Q:5</td>
                    <td colspan="4">Q:6</td>
                    <td colspan="4">Q:7</td>
                    <td colspan="4">Q:8</td>
                    <td colspan="4">Q:9</td>
                </tr>

                <tr>
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>   
                        
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 
                    
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                </tr>

                <tr>
                        <td><input type="text" class="small-input" id="q1a" name="q1a"></td>
                        <td><input type="text" class="small-input" id="q1b" name="q1b"></td>
                        <td><input type="text" class="small-input" id="q1c" name="q1c"></td>
                        <td><input type="text" class="small-input" id="q1d" name="q1d"></td>


                        <td><input type="text" class="small-input" id="q2a" name="q2a"></td>
                        <td><input type="text" class="small-input" id="q2b" name="q2b"></td>
                        <td><input type="text" class="small-input" id="q2c" name="q2c"></td>
                        <td><input type="text" class="small-input" id="q2d" name="q2d"></td>

                        <td><input type="text" class="small-input" id="q3a" name="q3a"></td>
                        <td><input type="text" class="small-input" id="q3b" name="q3b"></td>
                        <td><input type="text" class="small-input" id="q3c" name="q3c"></td>
                        <td><input type="text" class="small-input" id="q3d" name="q3d"></td>

                        <td><input type="text" class="small-input" id="q4a" name="q4a"></td>
                        <td><input type="text" class="small-input" id="q4b" name="q4b"></td>
                        <td><input type="text" class="small-input" id="q4c" name="q4c"></td>
                        <td><input type="text" class="small-input" id="q4d" name="q4d"></td>

                        <td><input type="text" class="small-input" id="q5a" name="q5a"></td>
                        <td><input type="text" class="small-input" id="q5b" name="q5b"></td>
                        <td><input type="text" class="small-input" id="q5c" name="q5c"></td>
                        <td><input type="text" class="small-input" id="q5d" name="q5d"></td>

                        <td><input type="text" class="small-input" id="q6a" name="q6a"></td>
                        <td><input type="text" class="small-input" id="q6b" name="q6b"></td>
                        <td><input type="text" class="small-input" id="q6c" name="q6c"></td>
                        <td><input type="text" class="small-input" id="q6d" name="q6d"></td>

                        <td><input type="text" class="small-input" id="q7a" name="q7a"></td>
                        <td><input type="text" class="small-input" id="q7b" name="q7b"></td>
                        <td><input type="text" class="small-input" id="q7c" name="q7c"></td>
                        <td><input type="text" class="small-input" id="q7d" name="q7d"></td>

                        <td><input type="text" class="small-input" id="q8a" name="q8a"></td>
                        <td><input type="text" class="small-input" id="q8b" name="q8b"></td>
                        <td><input type="text" class="small-input" id="q8c" name="q8c"></td>
                        <td><input type="text" class="small-input" id="q8d" name="q8d"></td>

                        <td><input type="text" class="small-input" id="q9a" name="q9a"></td>
                        <td><input type="text" class="small-input" id="q9b" name="q9b"></td>
                        <td><input type="text" class="small-input" id="q9c" name="q9c"></td>
                        <td><input type="text" class="small-input" id="q9d" name="q9d"></td>
                </tr>

                <tr>
                        <td colspan ="4" class="small-input"><p id="q1_out" name="q1_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q2_out" name="q2_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q3_out" name="q3_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q4_out" name="q4_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q5_out" name="q5_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q6_out" name="q6_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q7_out" name="q7_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q8_out" name="q8_out"></p></td>
                        <td colspan ="4" class="small-input"><p id="q9_out" name="q9_out"></p></td>
                </tr>
            </table>
        </div>

            <div class="Mark"><input type="submit" name="submit" value="Submit"></div>
        </form>
        <div class="Mark"><a href="show.php"><input type="submit" value="All Result"></a></div>
        <!--<script src="script.js"></script> -->
    </body>
</html>

<?php
        if(isset($_GET['insert_msg'])){
            echo "<h2 style='color:green'>".$_GET['insert_msg']."</h2>";
        }
?>
