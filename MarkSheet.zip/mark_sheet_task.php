<?php
include 'Connection.php';

   if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $q1a = intval($_POST['q1a']);
    $q1b = intval($_POST['q1b']);
    $q1c = intval($_POST['q1c']);
    $q1d = intval($_POST['q1d']);

    $q2a = intval($_POST['q2a']);
    $q2b = intval($_POST['q2b']);
    $q2c = intval($_POST['q2c']);
    $q2d = intval($_POST['q2d']);

    $q3a = intval($_POST['q3a']);
    $q3b = intval($_POST['q3b']);
    $q3c = intval($_POST['q3c']);
    $q3d = intval($_POST['q3d']);

    $q4a = intval($_POST['q4a']);
    $q4b = intval($_POST['q4b']);
    $q4c = intval($_POST['q4c']);
    $q4d = intval($_POST['q4d']);

    $q5a = intval($_POST['q5a']);
    $q5b = intval($_POST['q5b']);
    $q5c = intval($_POST['q5c']);
    $q5d = intval($_POST['q5d']);

    $q6a = intval($_POST['q6a']);
    $q6b = intval($_POST['q6b']);
    $q6c = intval($_POST['q6c']);
    $q6d = intval($_POST['q6d']);

    $q7a = intval($_POST['q7a']);
    $q7b = intval($_POST['q7b']);
    $q7c = intval($_POST['q7c']);
    $q7d = intval($_POST['q7d']);

    $q8a = intval($_POST['q8a']);
    $q8b = intval($_POST['q8b']);
    $q8c = intval($_POST['q8c']);
    $q8d = intval($_POST['q8d']);

    $q9a = intval($_POST['q9a']);
    $q9b = intval($_POST['q9b']);
    $q9c = intval($_POST['q9c']);
    $q9d = intval($_POST['q9d']);

    $sum1 = $q1a + $q1b + $q1c + $q1d;
    $sum2 = $q2a + $q2b + $q2c + $q2d;
    $sum3 = $q3a + $q3b + $q3c + $q3d;
    $sum4 = $q4a + $q4b + $q4c + $q4d;
    $sum5 = $q5a + $q5b + $q5c + $q5d;
    $sum6 = $q6a + $q6b + $q6c + $q6d;
    $sum7 = $q7a + $q7b + $q7c + $q7d;
    $sum8 = $q8a + $q8b + $q8c + $q8d;
    $sum9 = $q9a + $q9b + $q9c + $q9d;
    $sum = $sum1+$sum2+$sum3+$sum4+$sum5+$sum6+$sum7+$sum8+$sum9;

    $query = "INSERT INTO `result`(`id`, `q1a`, `q1b`, `q1c`, `q1d`, `q1total`, `q2a`, `q2b`, `q2c`, `q2d`, `q2total`, `q3a`, `q3b`, `q3c`, `q3d`, `q3total`, `q4a`, `q4b`, `q4c`, `q4d`, `q4total`, `q5a`, `q5b`, `q5c`, `q5d`, `q5total`, `q6a`, `q6b`, `q6c`, `q6d`, `q6total`, `q7a`, `q7b`, `q7c`, `q7d`, `q7total`, `q8a`, `q8b`, `q8c`, `q8d`, `q8total`, `q9a`, `q9b`, `q9c`, `q9d`, `q9total`, `sum`) 
    VALUES ('$id','$q1a','$q1b','$q1c','$q1d','$sum1','$q2a','$q2b','$q2c','$q2d','$sum2','$q3a','$q3b','$q3c','$q3d','$sum3','$q4a','$q4b','$q4c','$q4d','$sum4',
    '$q5a','$q5b','$q5c','$q5d','$sum5','$q6a','$q6b','$q6c','$q6d','$sum6',
    '$q7a','$q7b','$q7c','$q7d','$sum7','$q8a','$q8b','$q8c','$q8d','$sum8','$q9a','$q9b','$q9c','$q9d','$sum9', '$sum')";
    

    $res = mysqli_query($conn , $query);

    if(!$res){
        die("Query Failed".mysqli_error($conn));
    }
    else{
        header('location:index.php?insert_msg=Your data has been added successfully');
    }
   }
    


?>
