<?php
$conn = mysqli_connect("localhost", "root", "", "mark");
    // if($conn){
    //     echo "YES";
    // }
    // else{
    //     echo "NO";
    // }
?>