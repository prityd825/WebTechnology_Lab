<?php include "Connection.php"; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Mark Sheet</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
       <h1>Mark Sheet</h1>
       
        <div>
        <form method="GET">
            <input type="text" name="search" id="search" placeholder = "Student ID">
            <input type="submit" value="search">
        </form>
        
            <table align = "center">
            <tr>
                    <?php
                        if(isset($_GET['search'])){
                            $val = $_GET['search'];
                            $query = "select * from `result` where `id` = '$val'";
                        }
                        else{
                            $query = "SELECT * FROM `result`";
                        }
                        $res = mysqli_query($conn, $query);

                        if(mysqli_num_rows($res) == 0){
                            echo "NO Data Found";
                        }
                        else{
                            while($row = mysqli_fetch_assoc($res)){
                    ?>
                </tr>
                
                <tr>
                    <td class="student_id"> Student ID </td>
                    <td colspan="36">Marks</td>
                    <td> Total </td>
                </tr>
                <tr>
                
                    <td rowspan="4"><?php echo $row['id']; ?></td>
                    <td colspan="4">Q:1</td>
                    <td colspan="4">Q:2</td>
                    <td colspan="4">Q:3</td>
                    <td colspan="4">Q:4</td>
                    <td colspan="4">Q:5</td>
                    <td colspan="4">Q:6</td>
                    <td colspan="4">Q:7</td>
                    <td colspan="4">Q:8</td>
                    <td colspan="4">Q:9</td>
                    <td rowspan="4"><?php echo $row['sum']; ?></td>
                </tr>

                <tr>
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>   
                        
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 
                    
                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td> 

                    <td>a</td>
                    <td>b</td>
                    <td>c</td>
                    <td>d</td>

                </tr>

                <tr>
                    

                        <td class="small-input"><?php echo $row['q1a'];?></td>
                        <td class="small-input"><?php echo $row['q1b'];?></td>
                        <td class="small-input"><?php echo $row['q1c'];?></td>
                        <td class="small-input"><?php echo $row['q1d'];?></td>


                        <td class="small-input"><?php echo $row['q2a'];?></td>
                        <td class="small-input"><?php echo $row['q2b'];?></td>
                        <td class="small-input"><?php echo $row['q2c'];?></td>
                        <td class="small-input"><?php echo $row['q2d'];?></td>

                        <td class="small-input"><?php echo $row['q3a'];?></td>
                        <td class="small-input"><?php echo $row['q3b'];?></td>
                        <td class="small-input"><?php echo $row['q3c'];?></td>
                        <td class="small-input"><?php echo $row['q3d'];?></td>

                        <td class="small-input"><?php echo $row['q4a'];?></td>
                        <td class="small-input"><?php echo $row['q4b'];?></td>
                        <td class="small-input"><?php echo $row['q4c'];?></td>
                        <td class="small-input"><?php echo $row['q4d'];?></td>

                        <td class="small-input"><?php echo $row['q5a'];?></td>
                        <td class="small-input"><?php echo $row['q5b'];?></td>
                        <td class="small-input"><?php echo $row['q5c'];?></td>
                        <td class="small-input"><?php echo $row['q5d'];?></td>
`
                        <td class="small-input"><?php echo $row['q6a'];?></td>
                        <td class="small-input"><?php echo $row['q6b'];?></td>
                        <td class="small-input"><?php echo $row['q6c'];?></td>
                        <td class="small-input"><?php echo $row['q6d'];?></td>

                        <td class="small-input"><?php echo $row['q7a'];?></td>
                        <td class="small-input"><?php echo $row['q7b'];?></td>
                        <td class="small-input"><?php echo $row['q7c'];?></td>
                        <td class="small-input"><?php echo $row['q7d'];?></td>

                        <td class="small-input"><?php echo $row['q8a'];?></td>
                        <td class="small-input"><?php echo $row['q8b'];?></td>
                        <td class="small-input"><?php echo $row['q8c'];?></td>
                        <td class="small-input"><?php echo $row['q8d'];?></td>

                        <td class="small-input"><?php echo $row['q9a'];?></td>
                        <td class="small-input"><?php echo $row['q9b'];?></td>
                        <td class="small-input"><?php echo $row['q9c'];?></td>
                        <td class="small-input"><?php echo $row['q9d'];?></td>
                </tr>

                <tr>
                        <td colspan ="4" class="small-input"><?php echo $row['q1total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q2total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q3total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q4total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q5total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q6total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q7total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q8total']; ?></td>
                        <td colspan ="4" class="small-input"><?php echo $row['q9total']; ?></td>
                </tr>
                
                <tr>
                    
                    <?php
                        }
                    }
                    ?>
                </tr>
               
                
            </table>
        </div>
 
        
        <div class="Mark"><a href="show.php"><input type="submit" value="All Result"></a></div>
        <div class="Mark"><a href="index.php"><input type="submit" value="GO BACK"></a></div>
    </body>
</html>
