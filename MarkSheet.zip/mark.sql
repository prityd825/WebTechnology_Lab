-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2023 at 09:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mark`
--

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` varchar(255) NOT NULL,
  `q1a` int(11) NOT NULL,
  `q1b` int(11) NOT NULL,
  `q1c` int(11) NOT NULL,
  `q1d` int(11) NOT NULL,
  `q1total` int(11) NOT NULL,
  `q2a` int(11) NOT NULL,
  `q2b` int(11) NOT NULL,
  `q2c` int(11) NOT NULL,
  `q2d` int(11) NOT NULL,
  `q2total` int(11) NOT NULL,
  `q3a` int(11) NOT NULL,
  `q3b` int(11) NOT NULL,
  `q3c` int(11) NOT NULL,
  `q3d` int(11) NOT NULL,
  `q3total` int(11) NOT NULL,
  `q4a` int(11) NOT NULL,
  `q4b` int(11) NOT NULL,
  `q4c` int(11) NOT NULL,
  `q4d` int(11) NOT NULL,
  `q4total` int(11) NOT NULL,
  `q5a` int(11) NOT NULL,
  `q5b` int(11) NOT NULL,
  `q5c` int(11) NOT NULL,
  `q5d` int(11) NOT NULL,
  `q5total` int(11) NOT NULL,
  `q6a` int(11) NOT NULL,
  `q6b` int(11) NOT NULL,
  `q6c` int(11) NOT NULL,
  `q6d` int(11) NOT NULL,
  `q6total` int(11) NOT NULL,
  `q7a` int(11) NOT NULL,
  `q7b` int(11) NOT NULL,
  `q7c` int(11) NOT NULL,
  `q7d` int(11) NOT NULL,
  `q7total` int(11) NOT NULL,
  `q8a` int(11) NOT NULL,
  `q8b` int(11) NOT NULL,
  `q8c` int(11) NOT NULL,
  `q8d` int(11) NOT NULL,
  `q8total` int(11) NOT NULL,
  `q9a` int(11) NOT NULL,
  `q9b` int(11) NOT NULL,
  `q9c` int(11) NOT NULL,
  `q9d` int(11) NOT NULL,
  `q9total` int(11) NOT NULL,
  `sum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `q1a`, `q1b`, `q1c`, `q1d`, `q1total`, `q2a`, `q2b`, `q2c`, `q2d`, `q2total`, `q3a`, `q3b`, `q3c`, `q3d`, `q3total`, `q4a`, `q4b`, `q4c`, `q4d`, `q4total`, `q5a`, `q5b`, `q5c`, `q5d`, `q5total`, `q6a`, `q6b`, `q6c`, `q6d`, `q6total`, `q7a`, `q7b`, `q7c`, `q7d`, `q7total`, `q8a`, `q8b`, `q8c`, `q8d`, `q8total`, `q9a`, `q9b`, `q9c`, `q9d`, `q9total`, `sum`) VALUES
('BFH2025021F', 0, 5, 4, 0, 9, 0, 10, 0, 0, 10, 9, 0, 0, 0, 9, 0, 9, 0, 0, 9, 9, 0, 0, 0, 9, 7, 0, 0, 0, 7, 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63),
('BFH2025022F', 10, 0, 0, 0, 10, 2, 3, 4, 0, 9, 0, 9, 0, 0, 9, 0, 3, 2, 0, 5, 0, 3, 4, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 7, 0, 0, 13, 8, 0, 0, 0, 8, 61);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
