
const addToCartButtons = document.querySelectorAll('.add-to-cart');

const cartItemsContainer = document.querySelector('.cart-items');
const clearCartButton = document.getElementById('clear-cart');

const cart = [];

addToCartButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
       
        const product = {
            name: button.parentElement.querySelector('.product-name').textContent,
            price: button.parentElement.querySelector('.product-price').textContent
        };

      
        cart.push(product);

        updateCartDisplay();

        button.parentElement.style.display = 'none';
    });
});


clearCartButton.addEventListener('click', () => {
    clearCart();
});

function updateCartDisplay() {
    cartItemsContainer.innerHTML = '';

    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <span>${item.name}</span>
            <span>${item.price}</span>
            <button class="remove-from-cart" data-index="${index}">Remove</button>
        `;

        const removeButton = cartItem.querySelector('.remove-from-cart');
        removeButton.addEventListener('click', () => {
            const itemIndex = removeButton.getAttribute('data-index');
            removeItemFromCart(itemIndex);
        });

        cartItemsContainer.appendChild(cartItem);
    });

  
    const totalItems = document.getElementById('total-items');
    const totalPrice = document.getElementById('total-price');
    totalItems.textContent = cart.length;
    const total = cart.reduce((sum, item) => sum + parseFloat(item.price.replace('$', '')), 0);
    totalPrice.textContent = total.toFixed(2);
}


function removeItemFromCart(itemIndex) {
    cart.splice(itemIndex, 1);
    updateCartDisplay();
}

function clearCart() {
    cart.length = 0;
    updateCartDisplay();

    addToCartButtons.forEach((button) => {
        button.parentElement.style.display = 'block';
    });
}
